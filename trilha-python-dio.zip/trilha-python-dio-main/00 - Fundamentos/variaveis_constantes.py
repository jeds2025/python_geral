nome = "Guilherme"
idade = 28

nome, idade = "Giovanna", 27

print(nome, idade)

limite_saque_diario = 1000

BRAZILIAN_STATES = ["SP", "RJ", "SC", "RS"]

print(BRAZILIAN_STATES)
