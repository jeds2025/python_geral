frutas = (
    "laranja",
    "pera",
    "uva",
    "mamão"
)
print(frutas)
# Tuplas são imutáveis, ou seja, não podem ser alteradas após a criação

letras = tuple("python-3.10")
print(letras)

numeros = tuple([1, 2, 3, 4])
print(numeros)

pais = ("Brasil",)
print(pais)
