conjunto_a = {1, 2}
conjunto_b = {3, 4}
conjunto_c = {5, 6}
# Unindo dois conjuntos

resultado = conjunto_a.union(conjunto_b, conjunto_c)
# Unindo três conjuntos

print(resultado)
