numeros = {1, 2, 3, 1, 2, 4, 5, 5, 6, 7, 8, 9, 0}

print(1 in numeros)  # True
print(10 in numeros)  # False
print(0 in numeros)  # True
print("a" in numeros)  # False
print(5 in numeros)  # True
