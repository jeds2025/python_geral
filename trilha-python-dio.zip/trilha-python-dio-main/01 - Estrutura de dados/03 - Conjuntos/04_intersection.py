conjunto_a = {1, 2, 3}
conjunto_b = {2, 3, 4}
conjunto_c = {2, 3, 4}
# Intersecção entre dois conjuntos

resultado = conjunto_a.intersection(conjunto_b, conjunto_c)
# Intersecção entre três conjuntos
print(resultado)
