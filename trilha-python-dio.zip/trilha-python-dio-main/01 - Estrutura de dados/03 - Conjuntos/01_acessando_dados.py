numeros = {1, 2, 3, 2}

numeros = list(numeros)

print(numeros[0])
print(numeros[1])
print(numeros[2])
print(numeros[-1])  # 3
# Conjuntos não possuem ordem, então o índice pode não corresponder ao esperado

