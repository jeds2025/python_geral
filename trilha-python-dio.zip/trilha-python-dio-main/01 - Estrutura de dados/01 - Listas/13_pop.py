linguagens = ["python", "js", "c#", "c", "java", "csharp"]
# Exemplo de uso do método pop

print(linguagens.pop())  # csharp
print(linguagens.pop())  # java
print(linguagens.pop())  # c
print(linguagens.pop(0))  # python
print(linguagens.pop(0))  # js
print(linguagens.pop(0)) # c#
   




