linguagens = ["python", "js", "c", "java", "csharp"]
# Exemplo de uso do método index
print(linguagens.index("c"))  # 2
print(linguagens.index("java"))  # 3
print(linguagens.index("python"))  # 0
