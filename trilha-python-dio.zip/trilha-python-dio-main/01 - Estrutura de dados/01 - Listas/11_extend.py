linguagens = ["python", "js", "c"]

print(linguagens)  # ["python", "js", "c"]

linguagens.extend(["java", "csharp", "js"])

print(linguagens)  # ["python", "js", "c", "java", "csharp", "js"]
# Extendendo uma lista com outra lista


