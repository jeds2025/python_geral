linguagens = ["python", "js", "c", "java", "csharp", "c++"]

print(len(linguagens))  # 6
