linguagens = ["python", "js", "c", "java", "csharp"]

linguagens.remove("c")
linguagens.remove("js")

print(linguagens)  # ["python", "java", "csharp"]
