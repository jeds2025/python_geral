carros = ["gol", "celta", "palio", "verona", "civic", "corolla", "hb20"]

for carro in carros:
    print(carro)


for numera, carro in enumerate(carros):
    print(f"{numera}: {carro}")
