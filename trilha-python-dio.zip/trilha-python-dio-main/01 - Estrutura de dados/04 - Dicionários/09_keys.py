contatos  = {
    "guilherme@gmail.com": {"nome": "Guilherme", "telefone": "3333-2221"},
    "giovanna@gmail.com": {"nome": "Giovanna", "telefone": "3443-2121"},
    "chappie@gmail.com": {"nome": "Chappie", "telefone": "3344-9871"},
    "melaine@gmail.com": {"nome": "Melaine", "telefone": "3333-7766"},
}
# Retorna as chaves do dicionário

resultado = contatos.keys()  
# dict_keys(['guilherme@gmail.com', 'giovanna@gmail.com', 'chappie@gmail.com', 'melaine@gmail.com'])
print(resultado)
