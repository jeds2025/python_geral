from datetime import date, datetime, time

data = date(2023, 7, 10)
print(data)
print(date.today())
print()

data_hora = datetime(2023, 7, 10)
print(data_hora)
print(datetime.today())
print(datetime.now())
print()

hora = time(10, 20, 0)
print(hora)
print()