from sqlite3 import Connection, Cursor


def criar_bd(cursor: Cursor) -> None:
    pass


def criar_conexao() -> Connection:
    pass
